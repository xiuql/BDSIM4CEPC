# convert mad to gmad
