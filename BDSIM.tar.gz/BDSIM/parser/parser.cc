/*
 *  interactive gmad
 *  Ilya Agapov 2005
 */


#include "gmad.h"
#include <stdio.h>
#include <iostream>

using namespace std;

int main(int argc, char *argv[])
{
  cout<<endl;
  gmad_parser(stdin);
}
